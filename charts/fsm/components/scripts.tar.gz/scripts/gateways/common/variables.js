(
  {
    healthCheckTargets: {},
    healthCheckServices: {},
  }
)